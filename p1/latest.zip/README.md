﻿# GraphQL starter

An in-memory GraphQL API built with Apollo Server and Bun.

## Start

```sh
cd p1
bun install
bun run index.ts
```

The server listens on port 4000. Set `PORT` to use another port. Open the printed URL in a GraphQL client.

## Queries

```graphql
query {
  users(search: "ash", first: 10) {
    nodes { id name role posts { id title } }
    pageInfo { totalCount hasNextPage endCursor }
  }
  posts(tag: "habits") {
    nodes { id title author { name } }
    pageInfo { totalCount hasNextPage endCursor }
  }
}
```

`users` supports `search` and `role`; `posts` supports `search`, `tag`, and `authorId`. Both lists use `first` and numeric `after` cursors. Page sizes are limited to 100. `user(id:)`, `post(id:)`, `roles`, and `health` provide direct lookups and service metadata.

## Mutations

`createUser`, `updateUser`, and `deleteUser` manage users. Users with posts cannot be deleted. `createPost`, `updatePost`, and `deletePost` manage posts. Post creation requires an existing author. Names, titles, descriptions, and tags are trimmed and validated.

All records are kept in memory and reset when the process exits. This example is intended for learning and local development, not persistent storage.
